/*
 *
 */
$(function(){$("#tabs").tabs(),$("ul.ui-tabs-nav").show()});