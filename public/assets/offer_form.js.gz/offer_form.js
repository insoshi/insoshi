/*
 *
 */
$(function(){$("#offer_expiration_date").live.datepicker({buttonImage:"/images/calendar.gif",buttonImageOnly:!0,dateFormat:"yy-mm-dd"})});